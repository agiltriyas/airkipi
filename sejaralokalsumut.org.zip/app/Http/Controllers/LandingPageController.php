<?php

namespace App\Http\Controllers;

use App\Models\Content;
use Illuminate\Http\Request;

class LandingPageController extends Controller
{
    public function index()
    {
        // hihglight
        $data['highlight'] = Content::with('user')->where('isHighlight', 1)->orderBy('created_at', 'DESC')->take(3)->publish()->get();
        $data['highlight2'] = Content::with('user')->where('isHighlight', 1)->orderBy('created_at', 'DESC')->take(2)->publish()->get();
        // popular
        $data['popular'] = Content::with('user')->where('isPopular', 1)->orderBy('created_at', 'DESC')->take(4)->publish()->get();
        // kategori
        $data['kategori'] = Content::with('user')->orderBy('created_at', 'DESC')->publish()->get();
        //hikayat
        $data['hikayat'] = Content::with('user')->where('kategori', 'hikayat')->orderBy('created_at', 'DESC')->take(2)->publish()->get();
        $data['hikayat2'] = Content::with('user')->where('kategori', 'hikayat')->orderBy('created_at', 'DESC')->skip(2)->take(4)->publish()->get();

        $data['latest'] = Content::with('user')->orderBy('created_at', 'DESC')->take(1)->publish()->get();
        $data['latest2'] = Content::with('user')->orderBy('created_at', 'DESC')->take(2)->publish()->get();


        return view('home', compact('data'));
    }
}
