

<?php $__env->startSection('content-admin'); ?>


    <div class="row">
        <!-- /# column -->
        <div class="col-lg-12">
            <div class="card alert">
                <div class="card-header">
                    <h4>Content List </h4>
                    <div class="card-header-right-icon">
                        <ul>
                            
                            <li class=""><a href="#search"><i class="ti-search"></i></a></li>
                            <li class="doc-add"><a href="#"><i class="ti-plus"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Kategori</th>
                                    <th>Title</th>
                                    <th>Status</th>
                                    <th>Author</th>
                                    <th style="width:5%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td scope="row">1</td>
                                    <td>Kolor Tea Shirt For Man</td>
                                    <td><span class="badge badge-primary">Sale</span></td>
                                    <td>January 22</td>
                                    <td class="color-primary">$21.56</td>
                                    <td>
                                        <a href="#"><i class="ti-pencil"></i></a>
                                        <a href="#"><i class="ti-eye"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">2</th>
                                    <td>Kolor Tea Shirt For Women</td>
                                    <td><span class="badge badge-success">Tax</span></td>
                                    <td>January 30</td>
                                    <td class="color-success">$55.32</td>
                                    <td>
                                        <a href="#"><i class="ti-plus"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">3</th>
                                    <td>Blue Backpack For Baby</td>
                                    <td><span class="badge badge-danger">Extended</span></td>
                                    <td>January 25</td>
                                    <td class="color-danger">$14.85</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /# card -->
        </div>
        <!-- /# column -->
    </div>
    <div id="search">
        <button type="button" class="close">×</button>
        <form action="#" method="GET">
            <input type="search" value="" placeholder="type keyword(s) here" />
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="footer">
                <p>This dashboard was generated on <span id="date-time"></span> <a href="#" class="page-refresh">Refresh
                        Dashboard</a></p>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin',
    [
    'title' => 'Content Menu',
    'breadcrumbs'=>[
            [
                'name'=> 'Content', 
                'url' => 'content'
            ]
        ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sejaralokalsumut.org\resources\views/admin/content.blade.php ENDPATH**/ ?>