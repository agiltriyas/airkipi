

<?php $__env->startSection('content-admin'); ?>


<div class="row">
    <!-- /# column -->
    <div class="col-lg-12">
        <div class="card alert">
            <div class="card-header">
                <h4>Content List </h4>
                <div class="card-header-right-icon">
                    <ul>
                        
                        <li class=""><a href="#search"><i class="ti-search"></i></a></li>
                        <li class="doc-add"><a href="<?php echo e(route('admin.content.create')); ?>"><i class="ti-plus"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Kategori</th>
                                <th>Title</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Author</th>
                                <th style="width:5%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($contents->firstItem() + $loop->index); ?></td>
                                <td><?php echo e($content->kategori); ?></td>
                                <td><?php echo e($content->title); ?></td>
                                <?php if($content->status == 'draft'): ?>
                                <td><span class="badge badge-danger"><?php echo e($content->status); ?></span></td>
                                <?php else: ?>
                                <td><span class="badge badge-primary"><?php echo e($content->status); ?></span></td>
                                <?php endif; ?>
                                <td><?php echo e($content->created_at); ?></td>
                                <td class="color-primary"><?php echo e($content->user->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.content.edit',$content->id)); ?>"><i class="ti-pencil"></i></a>
                                    <a href="<?php echo e(route('admin.content.destroy',$content->id)); ?>" onclick="event.preventDefault();
                                                  document.getElementById('destroy-form').submit();">
                                        <i class="ti-trash"></i>
                                    </a>
                                    <form id="destroy-form" action="<?php echo e(route('admin.content.destroy',$content->id)); ?>" method="POST" class="d-none">
                                        <?php echo method_field("DELETE"); ?>
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($contents->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
        <!-- /# card -->
    </div>
    <!-- /# column -->
</div>
<div id="search">
    <button type="button" class="close">×</button>
    <form action="#" method="GET">
        <input type="search" value="" placeholder="type keyword(s) here" />
        <button type="submit" class="btn btn-primary">Search</button>
    </form>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="footer">
            <p>This dashboard was generated on <span id="date-time"></span> <a href="#" class="page-refresh">Refresh
                    Dashboard</a></p>
        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin',
[
'title' => 'Content Menu',
'breadcrumbs'=>[
[
'name'=> 'Content',
'url' => 'content'
]
]
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sejaralokalsumut.org\resources\views/admin/content/index.blade.php ENDPATH**/ ?>