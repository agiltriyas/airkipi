

<?php $__env->startSection('content'); ?>

<!-- Popular news -->
<section class="bg-content">
    <!-- Popular news  header-->
    <div class="popular__news-header">
        <div class="container">
            <div class="row no-gutters">
                <div class="col-md-8 ">
                    <div class="card__post-carousel">
                        <?php $__currentLoopData = $data['highlight']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <!-- Post Article -->
                            <div class="card__post">
                                <div class="card__post__body">
                                    <a href="<?php echo e($highlight->slug); ?>">
                                        <img src="<?php echo e($highlight->thumbnail); ?>" class="img-fluid" alt="">
                                    </a>
                                    <div class="card__post__content bg__post-cover">
                                        <div class="card__post__category">
                                            <?php echo e($highlight->kategori); ?>

                                        </div>
                                        <div class="card__post__title">
                                            <h2>
                                                <a href="<?php echo e($highlight->slug); ?>">
                                                    <?php echo e($highlight->title); ?>

                                                </a>
                                            </h2>
                                        </div>
                                        <div class="card__post__author-info">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <a href="#">
                                                        by <?php echo e($highlight->user->name); ?>

                                                    </a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span>
                                                        <?php echo e(date('d F Y',strtotime($highlight->created_at))); ?>

                                                    </span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="popular__news-right">
                        <!-- Post Article -->
                        <?php $__currentLoopData = $data['highlight2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card__post ">
                            <div class="card__post__body card__post__transition">
                                <a href="./card-article-detail-v1.html">
                                    <img src="<?php echo e($highlight->thumbnail); ?>" class="img-fluid" alt="">
                                </a>
                                <div class="card__post__content bg__post-cover">
                                    <div class="card__post__category">
                                        <?php echo e($highlight->kategori); ?>

                                    </div>
                                    <div class="card__post__title">
                                        <h5>
                                            <a href="./card-article-detail-v1.html">
                                                <?php echo e($highlight->title); ?></a>
                                        </h5>
                                    </div>
                                    <div class="card__post__author-info">
                                        <ul class="list-inline">
                                            <li class="list-inline-item">
                                                <a href="./card-article-detail-v1.html">
                                                    by <?php echo e($highlight->user->name); ?>

                                                </a>
                                            </li>
                                            <li class="list-inline-item">
                                                <span>
                                                    <?php echo e(date('d F Y',strtotime($highlight->created_at))); ?>

                                                </span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Popular news header-->
    <!-- Popular news carousel -->
  
    <!-- End Popular news carousel -->
</section>
<!-- End Popular news -->

<!-- Popular news category -->
<section class="pt-0 bg-content">
    <div class="popular__section-news">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-8">
                    <div class="wrapper__list__article">
                        <h4 class="border_section">Hikayat Sumatera Utara</h4>
                    </div>
                    <div class="row ">
                        <?php $__currentLoopData = $data['hikayat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hikayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-12 col-md-6 mb-4">
                            <!-- Post Article -->
                            <div class="card__post ">
                                <div class="card__post__body card__post__transition">
                                    <a href="<?php echo e($hikayat->slug); ?>">
                                        <img src="<?php echo e($hikayat->thumbnail); ?>" class="img-fluid" alt="">
                                    </a>
                                    <div class="card__post__content bg__post-cover">
                                        <div class="card__post__category">
                                            <?php echo e($hikayat->kategori); ?>

                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="<?php echo e($hikayat->slug); ?>">
                                                    <?php echo e($hikayat->title); ?>

                                                </a>
                                            </h5>
                                        </div>
                                        <div class="card__post__author-info">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <a href="./card-article-detail-v1.html">
                                                        by <?php echo e($hikayat->user->name); ?>

                                                    </a>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span>
                                                        <?php echo e(date('d F Y',strtotime($hikayat->created_at))); ?>

                                                    </span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row ">
                        <div class="col-sm-12 col-md-6">
                            <div class="wrapp__list__article-responsive">
                                <?php $__currentLoopData = $data['hikayat2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hikayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="mb-3">
                                    <!-- Post Article -->
                                    <div class="card__post card__post-list">
                                        <div class="image-sm">
                                            <a href="<?php echo e($hikayat->slug); ?>">
                                                <img src="<?php echo e($hikayat->thumbnail); ?>" class="img-fluid" alt="">
                                            </a>
                                        </div>


                                        <div class="card__post__body ">
                                            <div class="card__post__content">

                                                <div class="card__post__author-info mb-2">
                                                    <ul class="list-inline">
                                                        <li class="list-inline-item">
                                                            <span class="text-primary">
                                                                by <?php echo e($hikayat->user->name); ?>

                                                            </span>
                                                        </li>
                                                        <li class="list-inline-item">
                                                            <span class="text-dark text-capitalize">
                                                                <?php echo e(date('d F Y',strtotime($hikayat->created_at))); ?>

                                                            </span>
                                                        </li>

                                                    </ul>
                                                </div>
                                                <div class="card__post__title">
                                                    <h6>
                                                        <a href="<?php echo e($hikayat->slug); ?>">
                                                            <?php echo e($hikayat->title); ?>

                                                        </a>
                                                    </h6>
                                                    

                                                </div>

                                            </div>


                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-md-12 col-lg-4">
                    <aside class="wrapper__list__article">
                        <h4 class="border_section">popular post</h4>
                        <div class="wrapper__list-number">

                            <!-- List Article -->
                            <?php $__currentLoopData = $data['popular']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card__post__list">
                                <div class="list-number">
                                    <span>
                                        <?php echo e($loop->iteration); ?>

                                    </span>
                                </div>
                                <a href="#" class="category">
                                    <?php echo e($popular->kategori); ?>

                                </a>
                                <ul class="list-inline">
                                    <li class="list-inline-item">

                                        <h5>
                                            <a href="<?php echo e($popular->slug); ?>">
                                                <?php echo e($popular->title); ?>


                                            </a>
                                        </h5>
                                    </li>
                                </ul>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </div>

    <!-- Post news carousel -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <aside class="wrapper__list__article">
                    <h4 class="border_section">Budaya</h4>
                </aside>
            </div>
            <div class="col-md-12">

                <div class="article__entry-carousel">
                    <?php $__currentLoopData = $data['kategori']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budaya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($budaya->kategori == 'Budaya'): ?>
                    <div class="item">
                        <!-- Post Article -->
                        <div class="article__entry">
                            <div class="article__image">
                                <a href="<?php echo e($budaya->slug); ?>">
                                    <img src=" <?php echo e($budaya->thumbnail); ?>" alt="" class="img-fluid">
                                </a>
                            </div>
                            <div class="article__content">
                                <ul class="list-inline">
                                    <li class="list-inline-item">
                                        <span class="text-primary">
                                            by <?php echo e($budaya->user->name); ?>

                                        </span>
                                    </li>
                                    <li class="list-inline-item">
                                        <span>
                                            <?php echo e(date('d F Y',strtotime($budaya->created_at))); ?>

                                        </span>
                                    </li>

                                </ul>
                                <h5>
                                    <a href="<?php echo e($budaya->slug); ?>">
                                        <?php echo e($budaya->title); ?>

                                    </a>
                                </h5>

                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- End Popular news category -->


    <!-- Popular news category -->
    <div class="mt-4">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <aside class="wrapper__list__article mb-0">
                        <h4 class="border_section">Tokoh</h4>
                        <div class="row">
                            <?php $__currentLoopData = $data['kategori']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tokoh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($tokoh->kategori == 'Tokoh'): ?>
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <!-- Post Article -->
                                    <div class="article__entry">
                                        <div class="article__image">
                                            <a href="<?php echo e($tokoh->slug); ?>">
                                                <img src="<?php echo e($tokoh->thumbnail); ?>" alt="" class="img-fluid">
                                            </a>
                                        </div>
                                        <div class="article__content">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by <?php echo e($tokoh->user->name); ?>

                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span>
                                                        <?php echo e(date('d F Y',strtotime($tokoh->created_at))); ?>

                                                    </span>
                                                </li>

                                            </ul>
                                            <h5>
                                                <a href="<?php echo e($tokoh->slug); ?>">
                                                    <?php echo e($tokoh->title); ?>

                                                </a>
                                            </h5>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </aside>
                </div>

                <div class="col-md-4">
                    <div class="sticky-top">
                        <aside class="wrapper__list__article">
                            <h4 class="border_section">
                                Latest post</h4>
                            <div class="wrapper__list__article-small">

                                <!-- Post Article -->
                                <?php $__currentLoopData = $data['latest']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="article__entry">
                                    <div class="article__image">
                                        <a href="<?php echo e($latest->slug); ?>">
                                            <img src="<?php echo e($latest->thumbnail); ?>" alt="" class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="article__content">
                                        <div class="article__category">
                                            <?php echo e($latest->kategori); ?>

                                        </div>
                                        <ul class="list-inline">
                                            <li class="list-inline-item">
                                                <span class="text-primary">
                                                    by <?php echo e($latest->user->name); ?>

                                                </span>
                                            </li>
                                            <li class="list-inline-item">
                                                <span class="text-dark text-capitalize">
                                                    <?php echo e(date('d F Y',strtotime($latest->created_at))); ?>

                                                </span>
                                            </li>

                                        </ul>
                                        <h5>
                                            <a href="<?php echo e($latest->slug); ?>">
                                                <?php echo e($latest->title); ?>

                                            </a>
                                        </h5>
                                        <p>
                                            <?php echo e($latest->subtitle); ?>

                                        </p>
                                        <a href="<?php echo e($latest->slug); ?>" class="btn btn-outline-primary mb-4 text-capitalize"> read
                                            more</a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $data['latest2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-3">
                                    <!-- Post Article -->
                                    <div class="card__post card__post-list">
                                        <div class="image-sm">
                                            <a href="<?php echo e($latest->slug); ?>">
                                                <img src="<?php echo e($latest->thumbnail); ?>" class="img-fluid" alt="">
                                            </a>
                                        </div>


                                        <div class="card__post__body ">
                                            <div class="card__post__content">

                                                <div class="card__post__author-info mb-2">
                                                    <ul class="list-inline">
                                                        <li class="list-inline-item">
                                                            <span class="text-primary">
                                                                by <?php echo e($latest->user->name); ?>

                                                            </span>
                                                        </li>
                                                        <li class="list-inline-item">
                                                            <span class="text-dark text-capitalize">
                                                                <?php echo e(date('d F Y',strtotime($latest->created_at))); ?>

                                                            </span>
                                                        </li>

                                                    </ul>
                                                </div>
                                                <div class="card__post__title">
                                                    <h6>
                                                        <a href="<?php echo e($latest->slug); ?>">
                                                            <?php echo e($latest->title); ?>

                                                        </a>
                                                    </h6>
                                                    <p class="d-none d-lg-block d-xl-block">
                
                                                </div>

                                            </div>


                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </aside>

                        <aside class="wrapper__list__article">
                            <h4 class="border_section">newsletter</h4>
                            <!-- Form Subscribe -->
                            <div class="widget__form-subscribe bg__card-shadow">
                                <h6>
                                    The most important world news and events of the day.
                                </h6>
                                <p><small>Get magzrenvi daily newsletter on your inbox.</small></p>
                                <div class="input-group ">
                                    <input type="text" class="form-control" placeholder="Your email address">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button">sign up</button>
                                    </div>
                                </div>
                            </div>
                        </aside>
                    </div>
                </div>

                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</section>
<!-- End Popular news category -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app',['title'=>'Halaman Utama','description' => 'Sejarah lokal sumatera utara dengan kategori hikayat, budaya, tokoh, situs, lagu daerah, laman sejarah  dan kesadaran penilaian terhadap sejarah'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sejaralokalsumut.org\resources\views/home.blade.php ENDPATH**/ ?>