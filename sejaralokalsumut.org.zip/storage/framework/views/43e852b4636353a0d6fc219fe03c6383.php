

<?php $__env->startSection('content'); ?>
<section class="bg-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Breadcrumb -->
                <ul class="breadcrumbs bg-light mb-4">
                    <li class="breadcrumbs__item">
                        <a href="index.html" class="breadcrumbs__url">
                            <i class="fa fa-home"></i> Home</a>
                    </li>
                    <li class="breadcrumbs__item">
                        <a href="index.html" class="breadcrumbs__url">News</a>
                    </li>
                    <li class="breadcrumbs__item breadcrumbs__item--current">
                        World
                    </li>
                </ul>
            </div>

        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <aside class="wrapper__list__article ">
                    <h4 class="border_section">Category title</h4>

                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- Post Article List -->
                    <div class="card__post card__post-list card__post__transition mt-30">
                        <div class="row ">
                            <div class="col-md-5">
                                <div class="card__post__transition">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" class="img-fluid w-100" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7 my-auto pl-0">
                                <div class="card__post__body ">
                                    <div class="card__post__content  ">
                                        <div class="card__post__category ">
                                            travel
                                        </div>
                                        <div class="card__post__author-info mb-2">
                                            <ul class="list-inline">
                                                <li class="list-inline-item">
                                                    <span class="text-primary">
                                                        by david hall
                                                    </span>
                                                </li>
                                                <li class="list-inline-item">
                                                    <span class="text-dark text-capitalize">
                                                        descember 09, 2016
                                                    </span>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="card__post__title">
                                            <h5>
                                                <a href="#">
                                                    Exercitation Ullamco Laboris Nisi Ut Aliquip
                                                </a>
                                            </h5>
                                            <p class="d-none d-lg-block d-xl-block mb-0">
                                                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et
                                                arcu iaculis placerat
                                                sollicitudin ut est. In fringilla dui dui.
                                            </p>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </aside>
            </div>
            <div class="col-md-4">
                <div class="sticky-top">
                    <aside class="wrapper__list__article ">
                        <!-- <h4 class="border_section">Sidebar</h4> -->
                        <div class="mb-4">
                            <div class="widget__form-search-bar  ">
                                <div class="row no-gutters">
                                    <div class="col">
                                        <input class="form-control border-secondary border-right-0 rounded-0"
                                            value="" placeholder="Search">
                                    </div>
                                    <div class="col-auto">
                                        <button
                                            class="btn btn-outline-secondary border-left-0 rounded-0 rounded-right">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wrapper__list__article-small">
                            <div class="mb-3">
                                <!-- Post Article -->
                                <div class="card__post card__post-list">
                                    <div class="image-sm">
                                        <a href="./card-article-detail-v1.html">
                                            <img src="images/placeholder/500x400.jpg" class="img-fluid" alt="">
                                        </a>
                                    </div>


                                    <div class="card__post__body ">
                                        <div class="card__post__content">

                                            <div class="card__post__author-info mb-2">
                                                <ul class="list-inline">
                                                    <li class="list-inline-item">
                                                        <span class="text-primary">
                                                            by david hall
                                                        </span>
                                                    </li>
                                                    <li class="list-inline-item">
                                                        <span class="text-dark text-capitalize">
                                                            descember 09, 2016
                                                        </span>
                                                    </li>

                                                </ul>
                                            </div>
                                            <div class="card__post__title">
                                                <h6>
                                                    <a href="./card-article-detail-v1.html">
                                                        6 Best Tips for Building a Good Shipping Boat
                                                    </a>
                                                </h6>
                                                <!-- <p class="d-none d-lg-block d-xl-block">
                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et arcu iaculis placerat
                sollicitudin ut est. In fringilla dui dui.
            </p> -->

                                            </div>

                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <!-- Post Article -->
                                <div class="card__post card__post-list">
                                    <div class="image-sm">
                                        <a href="./card-article-detail-v1.html">
                                            <img src="images/placeholder/500x400.jpg" class="img-fluid" alt="">
                                        </a>
                                    </div>


                                    <div class="card__post__body ">
                                        <div class="card__post__content">

                                            <div class="card__post__author-info mb-2">
                                                <ul class="list-inline">
                                                    <li class="list-inline-item">
                                                        <span class="text-primary">
                                                            by david hall
                                                        </span>
                                                    </li>
                                                    <li class="list-inline-item">
                                                        <span class="text-dark text-capitalize">
                                                            descember 09, 2016
                                                        </span>
                                                    </li>

                                                </ul>
                                            </div>
                                            <div class="card__post__title">
                                                <h6>
                                                    <a href="./card-article-detail-v1.html">
                                                        6 Best Tips for Building a Good Shipping Boat
                                                    </a>
                                                </h6>
                                                <!-- <p class="d-none d-lg-block d-xl-block">
                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et arcu iaculis placerat
                sollicitudin ut est. In fringilla dui dui.
            </p> -->

                                            </div>

                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <!-- Post Article -->
                                <div class="card__post card__post-list">
                                    <div class="image-sm">
                                        <a href="./card-article-detail-v1.html">
                                            <img src="images/placeholder/500x400.jpg" class="img-fluid" alt="">
                                        </a>
                                    </div>


                                    <div class="card__post__body ">
                                        <div class="card__post__content">

                                            <div class="card__post__author-info mb-2">
                                                <ul class="list-inline">
                                                    <li class="list-inline-item">
                                                        <span class="text-primary">
                                                            by david hall
                                                        </span>
                                                    </li>
                                                    <li class="list-inline-item">
                                                        <span class="text-dark text-capitalize">
                                                            descember 09, 2016
                                                        </span>
                                                    </li>

                                                </ul>
                                            </div>
                                            <div class="card__post__title">
                                                <h6>
                                                    <a href="./card-article-detail-v1.html">
                                                        6 Best Tips for Building a Good Shipping Boat
                                                    </a>
                                                </h6>
                                                <!-- <p class="d-none d-lg-block d-xl-block">
                Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et arcu iaculis placerat
                sollicitudin ut est. In fringilla dui dui.
            </p> -->

                                            </div>

                                        </div>


                                    </div>
                                </div>
                            </div>

                            <!-- Post Article -->
                            <div class="article__entry">
                                <div class="article__image">
                                    <a href="#">
                                        <img src="images/placeholder/500x400.jpg" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="article__content">
                                    <div class="article__category">
                                        travel
                                    </div>
                                    <ul class="list-inline">
                                        <li class="list-inline-item">
                                            <span class="text-primary">
                                                by david hall
                                            </span>
                                        </li>
                                        <li class="list-inline-item">
                                            <span class="text-dark text-capitalize">
                                                descember 09, 2016
                                            </span>
                                        </li>

                                    </ul>
                                    <h5>
                                        <a href="#">
                                            Proin eu nisl et arcu iaculis placerat sollicitudin ut est
                                        </a>
                                    </h5>
                                    <p>
                                        Maecenas accumsan tortor ut velit pharetra mollis. Proin eu nisl et arcu
                                        iaculis placerat sollicitudin ut
                                        est. In fringilla dui dui.
                                    </p>
                                    <a href="#" class="btn btn-outline-primary mb-4 text-capitalize"> read more</a>
                                </div>
                            </div>
                        </div>
                    </aside>

                    <aside class="wrapper__list__article">
                        <h4 class="border_section">newsletter</h4>
                        <!-- Form Subscribe -->
                        <div class="widget__form-subscribe bg__card-shadow">
                            <h6>
                                The most important world news and events of the day.
                            </h6>
                            <p><small>Get magzrenvi daily newsletter on your inbox.</small></p>
                            <div class="input-group ">
                                <input type="text" class="form-control" placeholder="Your email address">
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="button">sign up</button>
                                </div>
                            </div>
                        </div>
                    </aside>


                </div>
            </div>
        </div>

        <!-- Pagination -->
        <div class="pagination-area">
            <div class="pagination wow fadeIn animated" data-wow-duration="2s" data-wow-delay="0.5s"
                style="visibility: visible; animation-duration: 2s; animation-delay: 0.5s; animation-name: fadeIn;">
                <a href="#">
                    «
                </a>
                <a href="#">
                    1
                </a>
                <a class="active" href="#">
                    2
                </a>
                <a href="#">
                    3
                </a>
                <a href="#">
                    4
                </a>
                <a href="#">
                    5
                </a>

                <a href="#">
                    »
                </a>
            </div>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sejaralokalsumut.org\resources\views/category.blade.php ENDPATH**/ ?>