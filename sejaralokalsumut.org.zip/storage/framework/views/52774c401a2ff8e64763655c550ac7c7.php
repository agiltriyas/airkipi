

<?php $__env->startSection('content-admin'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card alert">
            <div class="card-header">
                <h4>Edit Content</h4>
            </div>
            <div class="card-body">
                <div class="basic-elements">
                    <form method="post" action="<?php echo e(route('admin.content.update', $content->id)); ?>" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Kategori</label>
                                    <select name="kategori" class="form-control">
                                        <option value="hikayat" <?php echo e($content->kategori == 'hikayat' ? 'selected' : ''); ?>>Hikayat</option>
                                        <option value="budaya" <?php echo e($content->kategori == 'budaya' ? 'selected' : ''); ?>>Budaya</option>
                                        <option value="tokoh" <?php echo e($content->kategori == 'tokoh' ? 'selected' : ''); ?>>Tokoh</option>
                                        <option value="situs" <?php echo e($content->kategori == 'situs' ? 'selected' : ''); ?>>Situs</option>
                                        <option value="lagu daerah" <?php echo e($content->kategori == 'lagu daerah' ? 'selected' : ''); ?>>Lagu Daerah</option>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Title</label>
                                    <input name="title" type="text" class="form-control" value="<?php echo e($content->title); ?>">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label>Popular</label>
                                    <select name="isPopular" class="form-control">
                                        <option value="1"  <?php echo e($content->isPopular ? 'selected' : ''); ?>>Yes</option>
                                        <option value="0" <?php echo e($content->isPopular == 0 ? 'selected' : ''); ?>>No</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="status" class="form-control">
                                        <option value="draft" <?php echo e($content->status == "draft" ? 'selected' : ''); ?>>draft</option>
                                        <option value="published" <?php echo e($content->status == "published" ? 'selected' : ''); ?>>Published</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="thumbnail">Thumbnail</label></br>
                                    <img src="<?php echo e(asset('storage/').'/'.$content->thumbnail); ?>" alt="">
                                    <input name="thumbnail" type="file" src="" alt="">
                                    <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Subkategori</label>
                                    <input name="subkategori" type="text" class="form-control" value="" disabled>
                                </div>
                                <div class="form-group">
                                    <label>Subtitle</label>
                                    <input name="subtitle" type="text" class="form-control" value="<?php echo e($content->subtitle); ?>">
                                    <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label>Highlight</label>
                                    <select name="isHighlight" class="form-control">
                                        option value="1"  <?php echo e($content->isPopular ? 'selected' : ''); ?>>Yes</option>
                                        <option value="0" <?php echo e($content->isPopular == 0 ? 'selected' : ''); ?>>No</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Tags</label>
                                    <input name="tags" type="text" class="form-control" value="<?php echo e($content->tags); ?>" placeholder="example : news,berita,olahraga">
                                    <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="image">Image</label></br>
                                    <small>size 800x500</small></br>
                                    <img src="<?php echo e(asset('storage/').'/'.$content->headerimage); ?>" alt="">
                                    <input name="headerimage" type="file" src="" alt="">

                                    <?php $__errorArgs = ['headerimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="Content">Content</label>
                                    <textarea class="form-control" name="content" id="contenteditor"><?php echo e($content->content); ?></textarea>
                                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                            </div>
                            <div class="col-lg-12 text-right">
                                <button class="btn btn-default" type="submit">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /# row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/35.4.0/classic/ckeditor.js"></script>
<script>
        ClassicEditor
          .create( document.querySelector( '#contenteditor' ),{ 
                ckfinder: {
                      uploadUrl: "<?php echo e(route('admin.content.uploadeditor').'?_token='.csrf_token()); ?>",
                }
          } )
          .then( editor => {
                console.log( editor );
          } )
          .catch( error => {
                console.error( error );
          } );
  </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-style'); ?>
    <style>
        .ck-editor__editable_inline {
            min-height: 200px;
        }
        
        .ck-editor__editable_inline * {
            color: black;
            padding-left: 10px;
        }
    </style>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin',
    [
    'title' => 'Content Menu',
    'breadcrumbs'=>[
            [
                'name'=> 'Content', 
                'url' => 'admin.content.index'
],
[
                'name'=> 'Edit', 
                'url' => 'edit'
            ]
        ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sejaralokalsumut.org\resources\views/admin/content/edit.blade.php ENDPATH**/ ?>