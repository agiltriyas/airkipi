<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
    <div class="nano">
        <div class="nano-content">
            <ul>
                <li class="label">Main</li>
                <li class="{{(Request::segment(2) == 'home') ? 'active' : ''}}"><a href="{{route('admin.home')}}"><i class="ti-home"></i> Dashboard </a></li>
                <li class="label">Content</li>
                <li class="{{(Request::segment(2) == 'content') ? 'active' : ''}}"><a href="{{route('admin.content.index')}}"><i class="ti-pencil-alt"></i> Management </a></li>
                <li><a href="app-event-calender.html"><i class="ti-view-list-alt"></i> Quiz </a></li>


                <li class="label">User</li>
                <li><a href="app-event-calender.html"><i class="ti-layout-grid2-alt"></i> Content </a></li>
                <li><a href="app-event-calender.html"><i class="ti-comments"></i> Comment </a></li>
                <li><a href="app-event-calender.html"><i class="ti-receipt"></i> Post </a></li>
                <li><a href="app-event-calender.html"><i class="ti-check"></i> Quiz </a></li>

                <li class="label">Data</li>
                <li><a href="app-event-calender.html"><i class="ti-user"></i> User Management </a></li>
            </ul>
        </div>
    </div>
</div>
<!-- /# sidebar -->